#include "../inc/jtest.h"

/*--------------------------------------------------------------------------------*/
/* Define Global Variables */
/*--------------------------------------------------------------------------------*/

char JTEST_FW_STR_BUFFER[JTEST_BUF_SIZE] = {0};

volatile JTEST_FW_t JTEST_FW = {0};
